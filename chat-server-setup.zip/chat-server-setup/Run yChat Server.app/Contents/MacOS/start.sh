#!/bin/bash

# Get the directory where this script is located
DIR="$(cd "$(dirname "$0")" && pwd)"

# Go to the app's parent folder (one level up from Contents/MacOS)
APP_DIR="$(cd "$DIR/.." && pwd)"

# Run server.js from that folder
exec /usr/local/bin/node "$APP_DIR/server.js"
